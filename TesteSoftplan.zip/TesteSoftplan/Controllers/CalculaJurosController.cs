﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace CalculaJuros.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalculaJurosController : ControllerBase
    {
        public ActionResult<double> CalculaJuros(double valorInicial, int meses)
        {


            double valorFinal = 0;

            valorFinal = valorInicial * Math.Pow((1.00 + 0.01),meses);

            valorFinal = Math.Truncate(100 * valorFinal) / 100;
            
            if (valorFinal < 0)
                return BadRequest("Valor incorreto");
            return Ok(valorFinal);

        }
    }
}