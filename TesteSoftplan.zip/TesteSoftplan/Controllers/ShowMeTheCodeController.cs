﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TesteSoftplan.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShowMeTheCodeController : Controller
    {
        public ActionResult<string> ShowMeTheCode()
        {
            string caminho = "https://github.com/SouzaThiago/TesteSoftplan";

            return Ok(caminho);
        }
    }
}